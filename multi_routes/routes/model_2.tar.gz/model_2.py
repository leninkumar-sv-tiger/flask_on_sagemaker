# -*- coding: utf-8 -*-

import calendar
from datetime import datetime
from collections import namedtuple
import re
import sys
import time

import numpy as np
import pandas as pd

        
def run_dataframe(data):
    print("------------------------ In Predict Function ------------------------")
    df = pd.DataFrame(json.loads(data["Body"].read()))
    df["Source"] = "From Model 2"
    return df

